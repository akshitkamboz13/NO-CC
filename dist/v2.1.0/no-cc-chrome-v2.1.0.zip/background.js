const INSTALL_URL = 'https://www.si4k.online/projects/no-cc?install';
const UNINSTALL_URL = 'https://www.si4k.online/projects/no-cc?uninstall';
const STORE_REVIEW_URL = 'https://chromewebstore.google.com/detail/no-cc-hide-youtube-captio/nghfjpepacogcjjjhdecphdaaaaljeel/reviews';
const SITE_REVIEW_URL = 'https://www.si4k.online/projects/no-cc?review';
const NOTIFICATION_ICON = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jf6kAAAAASUVORK5CYII=';
const RATE_NOTIFICATION_ID = 'no-cc-rate-request';
const RATE_MORE_OPTIONS_NOTIFICATION_ID = 'no-cc-rate-more-options';
const RATE_CHECK_ALARM = 'no-cc-rate-check';
const TEN_DAYS_MS = 10 * 24 * 60 * 60 * 1000;
const REMIND_LATER_MS = 3 * 24 * 60 * 60 * 1000;
const RATE_PROMPT_DEFAULTS = {
    installedAt: null,
    ratePromptStatus: 'pending',
    ratePromptRemindAt: null
};

const handledNotificationIds = new Set();

const shouldShowRatePrompt = (data) => {
    const now = Date.now();
    const installedAt = Number(data.installedAt) || 0;
    const status = data.ratePromptStatus || 'pending';
    const remindAt = Number(data.ratePromptRemindAt) || 0;

    if (status !== 'pending') return false;
    if (!installedAt) return false;
    if (now < installedAt + TEN_DAYS_MS) return false;
    if (remindAt && now < remindAt) return false;

    return true;
};

const createRateCheckAlarm = () => {
    chrome.alarms.create(RATE_CHECK_ALARM, { periodInMinutes: 60 });
};

const showRateMoreOptionsNotification = () => {
    chrome.notifications.clear(RATE_MORE_OPTIONS_NOTIFICATION_ID, () => {
        chrome.notifications.create(RATE_MORE_OPTIONS_NOTIFICATION_ID, {
            type: 'basic',
            iconUrl: NOTIFICATION_ICON,
            title: 'More rating options',
            message: 'Pick another option for No CC feedback.',
            buttons: [
                { title: 'Rate on No-CC site' },
                { title: "Don't wanna rate" }
            ],
            priority: 2,
            requireInteraction: true
        }, () => {
            if (chrome.runtime.lastError) {
                // Ignore silently: notifications may fail on some platforms/contexts
            }
        });
    });
};

const showRateNotification = () => {
    chrome.notifications.clear(RATE_NOTIFICATION_ID, () => {
        chrome.notifications.clear(RATE_MORE_OPTIONS_NOTIFICATION_ID, () => {
            chrome.notifications.create(RATE_NOTIFICATION_ID, {
                type: 'basic',
                iconUrl: NOTIFICATION_ICON,
                title: 'Loving No CC so far?',
                message: 'Choose where you want to rate No CC.',
                buttons: [
                    { title: 'Rate on Store' },
                    { title: 'More options' }
                ],
                priority: 2,
                requireInteraction: true
            }, () => {
                if (chrome.runtime.lastError) {
                    // Ignore silently: notifications may fail on some platforms/contexts
                }
            });
        });
    });
};

const checkAndMaybePromptForRating = () => {
    chrome.storage.local.get(['installedAt', 'ratePromptStatus', 'ratePromptRemindAt'], (data) => {
        if (!shouldShowRatePrompt(data)) return;
        showRateNotification();
    });
};

const markRated = () => {
    chrome.storage.local.set({
        ratePromptStatus: 'rated',
        ratePromptRemindAt: null
    });
};

const markDeclined = () => {
    chrome.storage.local.set({
        ratePromptStatus: 'declined',
        ratePromptRemindAt: null
    });
};

const remindLater = () => {
    chrome.storage.local.set({
        ratePromptStatus: 'pending',
        ratePromptRemindAt: Date.now() + REMIND_LATER_MS
    });
};

const openUrl = (url) => {
    chrome.tabs.create({ url }, () => {
        if (chrome.runtime.lastError) {
            // Ignore silently in unsupported contexts
        }
    });
};

chrome.runtime.setUninstallURL(UNINSTALL_URL, () => {
    if (chrome.runtime.lastError) {
        // Ignore silently to avoid noisy logs in unsupported contexts
    }
});

chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        chrome.storage.local.set({
            ...RATE_PROMPT_DEFAULTS,
            installedAt: Date.now()
        });
        chrome.tabs.create({ url: INSTALL_URL });
    }

    createRateCheckAlarm();
    checkAndMaybePromptForRating();
});

chrome.runtime.onStartup.addListener(() => {
    createRateCheckAlarm();
    checkAndMaybePromptForRating();
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== RATE_CHECK_ALARM) return;
    checkAndMaybePromptForRating();
});

chrome.notifications.onClicked.addListener((notificationId) => {
    if (notificationId !== RATE_NOTIFICATION_ID && notificationId !== RATE_MORE_OPTIONS_NOTIFICATION_ID) return;

    handledNotificationIds.add(notificationId);
    if (notificationId === RATE_NOTIFICATION_ID) {
        remindLater();
    }
    chrome.notifications.clear(notificationId);
});

chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
    if (notificationId !== RATE_NOTIFICATION_ID && notificationId !== RATE_MORE_OPTIONS_NOTIFICATION_ID) return;

    handledNotificationIds.add(notificationId);

    if (notificationId === RATE_NOTIFICATION_ID) {
        if (buttonIndex === 0) {
            markRated();
            openUrl(STORE_REVIEW_URL);
        } else if (buttonIndex === 1) {
            showRateMoreOptionsNotification();
        }
    } else if (notificationId === RATE_MORE_OPTIONS_NOTIFICATION_ID) {
        if (buttonIndex === 0) {
            markRated();
            openUrl(SITE_REVIEW_URL);
        } else if (buttonIndex === 1) {
            markDeclined();
        }
    }

    chrome.notifications.clear(notificationId);
});

chrome.notifications.onClosed.addListener((notificationId) => {
    if (notificationId !== RATE_NOTIFICATION_ID && notificationId !== RATE_MORE_OPTIONS_NOTIFICATION_ID) return;

    if (handledNotificationIds.has(notificationId)) {
        handledNotificationIds.delete(notificationId);
        return;
    }

    markDeclined();
});
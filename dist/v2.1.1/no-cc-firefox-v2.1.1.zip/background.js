const INSTALL_URL = 'https://www.si4k.online/projects/no-cc?install';
const UNINSTALL_URL = 'https://www.si4k.online/projects/no-cc?uninstall';
const STORE_REVIEW_URL = 'https://addons.mozilla.org/en-US/firefox/addon/no-cc/reviews/';
const SITE_REVIEW_URL = 'https://www.si4k.online/projects/no-cc?review';
const NOTIFICATION_ICON = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jf6kAAAAASUVORK5CYII=';
const RATE_NOTIFICATION_ID = 'no-cc-rate-request';
const RATE_MORE_OPTIONS_NOTIFICATION_ID = 'no-cc-rate-more-options';
const RATE_CHECK_ALARM = 'no-cc-rate-check';
const TEN_DAYS_MS = 10 * 24 * 60 * 60 * 1000;
const REMIND_LATER_MS = 3 * 24 * 60 * 60 * 1000;
const RATE_PROMPT_DEFAULTS = {
    installedAt: null,
    ratePromptStatus: 'pending',
    ratePromptRemindAt: null
};

const handledNotificationIds = new Set();

const shouldShowRatePrompt = (data) => {
    const now = Date.now();
    const installedAt = Number(data.installedAt) || 0;
    const status = data.ratePromptStatus || 'pending';
    const remindAt = Number(data.ratePromptRemindAt) || 0;

    if (status !== 'pending') return false;
    if (!installedAt) return false;
    if (now < installedAt + TEN_DAYS_MS) return false;
    if (remindAt && now < remindAt) return false;

    return true;
};

const createRateCheckAlarm = () => {
    browser.alarms.create(RATE_CHECK_ALARM, { periodInMinutes: 60 });
};

const showRateMoreOptionsNotification = async () => {
    try {
        await browser.notifications.clear(RATE_MORE_OPTIONS_NOTIFICATION_ID);
        await browser.notifications.create(RATE_MORE_OPTIONS_NOTIFICATION_ID, {
            type: 'basic',
            iconUrl: NOTIFICATION_ICON,
            title: 'More rating options',
            message: 'Pick another option for No CC feedback.',
            buttons: [
                { title: 'Rate on No-CC site' },
                { title: "Don't wanna rate" }
            ]
        });
    } catch {
        // Ignore silently in unsupported contexts
    }
};

const showRateNotification = async () => {
    try {
        await browser.notifications.clear(RATE_NOTIFICATION_ID);
        await browser.notifications.clear(RATE_MORE_OPTIONS_NOTIFICATION_ID);
        await browser.notifications.create(RATE_NOTIFICATION_ID, {
            type: 'basic',
            iconUrl: NOTIFICATION_ICON,
            title: 'Loving No CC so far?',
            message: 'Choose where you want to rate No CC.',
            buttons: [
                { title: 'Rate on Store' },
                { title: 'More options' }
            ]
        });
    } catch {
        // Ignore silently in unsupported contexts
    }
};

const checkAndMaybePromptForRating = async () => {
    try {
        const data = await browser.storage.local.get(['installedAt', 'ratePromptStatus', 'ratePromptRemindAt']);
        if (!shouldShowRatePrompt(data)) return;
        await showRateNotification();
    } catch {
        // Ignore silently in unsupported contexts
    }
};

const markRated = async () => {
    await browser.storage.local.set({
        ratePromptStatus: 'rated',
        ratePromptRemindAt: null
    });
};

const markDeclined = async () => {
    await browser.storage.local.set({
        ratePromptStatus: 'declined',
        ratePromptRemindAt: null
    });
};

const remindLater = async () => {
    await browser.storage.local.set({
        ratePromptStatus: 'pending',
        ratePromptRemindAt: Date.now() + REMIND_LATER_MS
    });
};

const openUrl = async (url) => {
    try {
        await browser.tabs.create({ url });
    } catch {
        // Ignore silently in unsupported contexts
    }
};

browser.runtime.setUninstallURL(UNINSTALL_URL).catch(() => {
    // Ignore silently to avoid noisy logs in unsupported contexts
});

browser.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        browser.storage.local.set({
            ...RATE_PROMPT_DEFAULTS,
            installedAt: Date.now()
        }).catch(() => {
            // Ignore storage write failures silently
        });
        browser.tabs.create({ url: INSTALL_URL });
    }

    createRateCheckAlarm();
    checkAndMaybePromptForRating();
});

browser.runtime.onStartup.addListener(() => {
    createRateCheckAlarm();
    checkAndMaybePromptForRating();
});

browser.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== RATE_CHECK_ALARM) return;
    checkAndMaybePromptForRating();
});

browser.notifications.onClicked.addListener((notificationId) => {
    if (notificationId !== RATE_NOTIFICATION_ID && notificationId !== RATE_MORE_OPTIONS_NOTIFICATION_ID) return;

    handledNotificationIds.add(notificationId);
    if (notificationId === RATE_NOTIFICATION_ID) {
        remindLater();
    }
    browser.notifications.clear(notificationId);
});

browser.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
    if (notificationId !== RATE_NOTIFICATION_ID && notificationId !== RATE_MORE_OPTIONS_NOTIFICATION_ID) return;

    handledNotificationIds.add(notificationId);

    if (notificationId === RATE_NOTIFICATION_ID) {
        if (buttonIndex === 0) {
            markRated();
            openUrl(STORE_REVIEW_URL);
        } else if (buttonIndex === 1) {
            showRateMoreOptionsNotification();
        }
    } else if (notificationId === RATE_MORE_OPTIONS_NOTIFICATION_ID) {
        if (buttonIndex === 0) {
            markRated();
            openUrl(SITE_REVIEW_URL);
        } else if (buttonIndex === 1) {
            markDeclined();
        }
    }

    browser.notifications.clear(notificationId);
});

browser.notifications.onClosed.addListener((notificationId) => {
    if (notificationId !== RATE_NOTIFICATION_ID && notificationId !== RATE_MORE_OPTIONS_NOTIFICATION_ID) return;

    if (handledNotificationIds.has(notificationId)) {
        handledNotificationIds.delete(notificationId);
        return;
    }

    markDeclined();
});
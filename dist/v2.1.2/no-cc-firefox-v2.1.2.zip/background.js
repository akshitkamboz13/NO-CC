const INSTALL_URL = 'https://www.si4k.online/projects/no-cc?install';
const UNINSTALL_URL = 'https://www.si4k.online/projects/no-cc?uninstall';
const STORE_REVIEW_URL = 'https://addons.mozilla.org/en-US/firefox/addon/no-cc/reviews/';
const CONTRIBUTION_URL = 'https://www.si4k.online/contribution';
const RATE_CHECK_ALARM = 'no-cc-rate-check';
const TEN_DAYS_MS = 10 * 24 * 60 * 60 * 1000;
const REMIND_LATER_MS = 3 * 24 * 60 * 60 * 1000;
const RATE_PROMPT_DEFAULTS = {
    installedAt: null,
    ratePromptStatus: 'pending',
    ratePromptRemindAt: null
};

const shouldShowRatePrompt = (data) => {
    const now = Date.now();
    const installedAt = Number(data.installedAt) || 0;
    const status = data.ratePromptStatus || 'pending';
    const remindAt = Number(data.ratePromptRemindAt) || 0;

    if (status !== 'pending') return false;
    if (!installedAt) return false;
    if (now < installedAt + TEN_DAYS_MS) return false;
    if (remindAt && now < remindAt) return false;

    return true;
};

const createRateCheckAlarm = () => {
    browser.alarms.create(RATE_CHECK_ALARM, { periodInMinutes: 60 });
};

const broadcastSoftRatePrompt = async () => {
    try {
        const tabs = await browser.tabs.query({ url: '*://*.youtube.com/*' });
        if (!tabs?.length) return;

        await Promise.all(tabs.map((tab) => {
            if (!tab.id) return Promise.resolve();
            return browser.tabs.sendMessage(tab.id, {
                type: 'noCc:showSoftRatePrompt',
                storeReviewUrl: STORE_REVIEW_URL,
                contributionUrl: CONTRIBUTION_URL
            }).catch(() => {
                // Ignore silently when content script is unavailable
            });
        }));
    } catch {
        // Ignore silently in unsupported contexts
    }
};

const checkAndMaybePromptForRating = async () => {
    try {
        const data = await browser.storage.local.get(['installedAt', 'ratePromptStatus', 'ratePromptRemindAt']);
        if (!shouldShowRatePrompt(data)) return;
        await broadcastSoftRatePrompt();
    } catch {
        // Ignore silently in unsupported contexts
    }
};

const markRated = async () => {
    await browser.storage.local.set({
        ratePromptStatus: 'rated',
        ratePromptRemindAt: null
    });
};

const markDeclined = async () => {
    await browser.storage.local.set({
        ratePromptStatus: 'declined',
        ratePromptRemindAt: null
    });
};

const remindLater = async () => {
    await browser.storage.local.set({
        ratePromptStatus: 'pending',
        ratePromptRemindAt: Date.now() + REMIND_LATER_MS
    });
};

const openUrl = async (url) => {
    try {
        await browser.tabs.create({ url });
    } catch {
        // Ignore silently in unsupported contexts
    }
};

const handleRatePromptAction = async (action) => {
    if (action === 'rate-store') {
        await markRated();
        await openUrl(STORE_REVIEW_URL);
        return;
    }

    if (action === 'contribute') {
        await markRated();
        await openUrl(CONTRIBUTION_URL);
        return;
    }

    if (action === 'remind-later') {
        await remindLater();
        return;
    }

    await markDeclined();
};

browser.runtime.setUninstallURL(UNINSTALL_URL).catch(() => {
    // Ignore silently to avoid noisy logs in unsupported contexts
});

browser.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        browser.storage.local.set({
            ...RATE_PROMPT_DEFAULTS,
            installedAt: Date.now()
        }).catch(() => {
            // Ignore storage write failures silently
        });
        browser.tabs.create({ url: INSTALL_URL });
    }

    createRateCheckAlarm();
    checkAndMaybePromptForRating();
});

browser.runtime.onStartup.addListener(() => {
    createRateCheckAlarm();
    checkAndMaybePromptForRating();
});

browser.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== RATE_CHECK_ALARM) return;
    checkAndMaybePromptForRating();
});

browser.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'noCc:requestRatePromptIfDue') {
        return browser.storage.local.get(['installedAt', 'ratePromptStatus', 'ratePromptRemindAt']).then((data) => ({
            showPrompt: shouldShowRatePrompt(data),
            storeReviewUrl: STORE_REVIEW_URL,
            contributionUrl: CONTRIBUTION_URL
        })).catch(() => ({
            showPrompt: false,
            storeReviewUrl: STORE_REVIEW_URL,
            contributionUrl: CONTRIBUTION_URL
        }));
    }

    if (msg?.type === 'noCc:ratePromptAction') {
        return handleRatePromptAction(msg.action).then(() => ({ ok: true })).catch(() => ({ ok: false }));
    }

    return undefined;
});